//
//  ViewController.swift
//  BLE MZ -
//
//  Created by C N on 6/16/17.
//  Copyright © 2017 C N. All rights reserved.
//

import UIKit
import CoreBluetooth

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var disconnectButton: UIButton!
    
    // BLE
    var centralManager : CBCentralManager!
    var sensorTagPeripheral : CBPeripheral!
    var temperatureCharacteristic:CBCharacteristic?
    var humidityCharacteristic:CBCharacteristic?
    var movementCharacteristic:CBCharacteristic?
    var accelerometerCharacteristic:CBCharacteristic?
    
    // define our scanning interval times
    let timerPauseInterval:TimeInterval = 10.0
    let timerScanInterval:TimeInterval = 2.0
    var keepScanning = false
    
    // UI-related
    let temperatureLabelFontName = "HelveticaNeue-Thin"
    let temperatureLabelFontSizeMessage:CGFloat = 56.0
    let temperatureLabelFontSizeTemp:CGFloat = 81.0
    var lastTemperatureTens = 0
    let defaultInitialTemperature = -9999
    var lastTemperature:Int!
    var ambientTempC, ambientTempF : Double!
    var switchStatus = false
    
    // Second Controller Data
    var demoTemperature = [67, 79, 85, 82, 84, 78, 69, 89]
    var tempChange = [Int]()
    var timeStamps = [String]()
    var demoTime = ["9:41", "9:42", "9:43", "9:44", "9:45", "9:46", "9:47", "9:48",]
    var date = Date()
    let formatter = DateFormatter()
    var currentDate = "", currentTime = ""
    var counter = 0
    
    // IR Temp, Humidity UUIDs
    let IRTemperatureServiceUUID = CBUUID(string: "F000AA00-0451-4000-B000-000000000000")
    let IRTemperatureDataUUID = CBUUID(string: "F000AA01-0451-4000-B000-000000000000")
    let IRTemperatureConfig = CBUUID(string: "F000AA02-0451-4000-B000-000000000000")
    
    let HumidityServiceUUID = CBUUID(string: "F000AA20-0451-4000-B000-000000000000")
    let HumidityDataUUID = CBUUID(string: "F000AA21-0451-4000-B000-000000000000")
    let HumidityConfig = CBUUID(string: "F000AA22-0451-4000-B000-000000000000")
    
    let MovementServiceUUID = CBUUID(string: "F000AA80-0451-4000-B000-000000000000")
    let MovementDataUUID = CBUUID(string: "F000AA81-0451-4000-B000-000000000000")
    let MovementConfigUUID = CBUUID(string: "F000AA82-0451-4000-B000-000000000000")
    
    let GyroscopeDataUUID = CBUUID(string: "F000AA51-0451-4000-B000-000000000000")
    let GyroscopeConfigUUID = CBUUID(string: "F000AA52-0451-4000-B000-000000000000")

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondController = segue.destination as! SecondViewController
        if tempChange.isEmpty {
            secondController.tempChange = self.demoTemperature
            secondController.currentTime = self.demoTime
        } else {
            secondController.tempChange = self.tempChange
            secondController.temp = lastTemperature
            secondController.currentDate = self.currentDate
            secondController.currentTime = self.timeStamps
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Initialize central manager on load
        centralManager = CBCentralManager(delegate: self, queue: nil, options: nil)
        
        self.loadData()
    }
    
    func loadData() {
        formatter.dateFormat = "MM/dd/yy"
        currentDate = formatter.string(from: date)
        formatter.dateFormat = "hh:mm"
        currentTime = formatter.string(from: date)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: BLE Status
    //Check status of BLE hardware
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            // Scan for peripherals if BLE is turned on
            central.scanForPeripherals(withServices: nil, options: nil)
            self.statusLabel.text = "Searching for BLE Devices"
        }
        else {
            // Can have different conditions for all states if needed - print generic message
            print("Bluetooth switched off or not initialized")
        }
    }
    
    // Check out the discovered peripherals to find Sensor Tag
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let deviceName = "CC2650 SensorTag"
        let nameOfDeviceFound = (advertisementData as NSDictionary).object(forKey: CBAdvertisementDataLocalNameKey) as? String
        
        if nameOfDeviceFound == deviceName {
            // Update Status Label
            self.statusLabel.text = "Sensor Tag Found"
            titleLabel.text = "SensorTag 2.0"
            
            // Stop scanning
            self.centralManager.stopScan()
            // Set as the peripheral to use and establish connection
            self.sensorTagPeripheral = peripheral
            self.sensorTagPeripheral.delegate = self
            self.centralManager.connect(peripheral, options: nil)
        } else {
            self.statusLabel.text = "Sensor Tag NOT Found"
        }
    }
    
    // Discover services of the peripheral
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        self.statusLabel.text = "Discovering peripheral services"
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }
    
    // Check if the service is discovered a valid IR Temperature Service
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        self.statusLabel.text = "Looking at peripheral services"
        if let services = peripheral.services {
            for service in services {
                let thisService = service as CBService
                
                if service.uuid == IRTemperatureServiceUUID || service.uuid == HumidityServiceUUID || service.uuid == MovementServiceUUID {
                    peripheral.discoverCharacteristics(nil, for: thisService)
                }
                print(service.uuid)
            }
        }
    }
    
    // Enable notification and sensor for each characteristic of valid service
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        // update status label
        self.statusLabel.text = "Enabling Sensors"
        
        guard let characteristics = service.characteristics
            else { print("Unable to retrieve service characteristics"); return }
        
        var enableValue: UInt8 = 1
        let enableBytes = NSData(bytes: &enableValue, length: MemoryLayout<UInt8>.size)
        
        for characteristic in characteristics {
            
            switch(characteristic.uuid) {
            case IRTemperatureDataUUID:
                self.sensorTagPeripheral.setNotifyValue(true, for: characteristic)
                temperatureCharacteristic = characteristic
            case IRTemperatureConfig:
                self.sensorTagPeripheral.writeValue(enableBytes as Data, for: characteristic, type: .withResponse)
            case HumidityDataUUID:
                self.sensorTagPeripheral.setNotifyValue(true, for: characteristic)
            case HumidityConfig:
                self.sensorTagPeripheral.writeValue(enableBytes as Data, for: characteristic, type: .withResponse)
                humidityCharacteristic = characteristic
            case MovementDataUUID:
                accelerometerCharacteristic = characteristic
                self.sensorTagPeripheral.setNotifyValue(true, for: characteristic)
                self.sensorTagPeripheral.readValue(for: characteristic)
            case MovementConfigUUID:
                self.sensorTagPeripheral.writeValue(enableBytes as Data, for: characteristic, type: .withResponse)
                movementCharacteristic = characteristic
            default:
                break
            }
        }
    }
    
    
    // Get data values when they are updated
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        self.statusLabel.text = "Connected"
        
        switch(characteristic.uuid) {
        case IRTemperatureDataUUID:
            displayTemperature(characteristic.value!)
            fallthrough
        case HumidityDataUUID:
            print("Humidity: \(characteristic.value!)")
            displayHumidity(characteristic.value!)
            fallthrough
        case MovementDataUUID:
            print(characteristic)
            //Accelerometer
            fallthrough
        default:
            break
        }
    }
    
    // If disconnected, start searching again
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        self.statusLabel.text = "Disconnected"
        central.scanForPeripherals(withServices: nil, options: nil)
    }
    
    // MARK: - Handling User Interaction
    @IBAction func handleDisconnectButtonTapped(_ sender: AnyObject) {
        // if we don't have a sensor tag, start scanning for one...
        if sensorTagPeripheral == nil {
            keepScanning = true
            resumeScan()
            return
        } else {
            disconnect()
        }
    }
    
    func disconnect() {
        if let sensorTag = self.sensorTagPeripheral {
            if let tc = self.temperatureCharacteristic {
                sensorTagPeripheral.setNotifyValue(false, for: tc)
            }
            if let hc = self.humidityCharacteristic {
                sensorTagPeripheral.setNotifyValue(false, for: hc)
            }
            centralManager.cancelPeripheralConnection(sensorTag)
        }
        temperatureCharacteristic = nil
        humidityCharacteristic = nil
    }
    
    // MARK: - Bluetooth scanning
    func pauseScan() {
        // Scanning uses up battery on phone, so pause the scan process for the designated interval.
        print("*** PAUSING SCAN...")
        _ = Timer(timeInterval: timerPauseInterval, target: self, selector: #selector(resumeScan), userInfo: nil, repeats: false)
        centralManager.stopScan()
        disconnectButton.isEnabled = true
    }
    
    func resumeScan() {
        if keepScanning {
            // Start scanning again...
            print("*** RESUMING SCAN!")
            disconnectButton.isEnabled = false
            temperatureLabel.font = UIFont(name: temperatureLabelFontName, size: temperatureLabelFontSizeMessage)
            temperatureLabel.text = "Searching"
            _ = Timer(timeInterval: timerScanInterval, target: self, selector: #selector(pauseScan), userInfo: nil, repeats: false)
            centralManager.scanForPeripherals(withServices: nil, options: nil)
        } else {
            disconnectButton.isEnabled = true
        }
    }
    
    // MARK: Change between C and F
    @IBAction func switchController(_ sender: UISwitch) {
        if sender.isOn {
            if ambientTempC == nil {
                switchStatus = false
                sender.setOn(false, animated: true)
                let alertController = UIAlertController(title: "BLE Device Not Found", message: "Celsius Temperature Cannot Be Displayed", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            } else {
                switchStatus = true
                lastTemperature = Int(ambientTempC)
                updateTemperatureDisplay()
            }
        } else {
            switchStatus = false
        }
    }
    
    // MARK: Display Temperature
    func displayTemperature(_ data:Data) {
        // We'll get four bytes of data back, so we divide the byte count by two
        // because we're creating an array that holds two 16-bit (two-byte) values
        let dataLength = data.count / MemoryLayout<UInt16>.size
        var dataArray = [UInt16](repeating: 0, count: dataLength)
        (data as NSData).getBytes(&dataArray, length: dataLength * MemoryLayout<Int16>.size)
        
        //        // output values for debugging/diagnostic purposes
        //        for i in 0 ..< dataLength {
        //            let nextInt:UInt16 = dataArray[i]
        //            print("next int: \(nextInt)")
        //        }
        
        let rawAmbientTemp:UInt16 = dataArray[Device.SensorDataIndexTempAmbient]
        ambientTempC = Double(rawAmbientTemp) / 128.0
        ambientTempF = convertCelciusToFahrenheit(ambientTempC)
        print("*** AMBIENT TEMPERATURE SENSOR (C/F): \(ambientTempC), \(ambientTempF)");
        
        // Device also retrieves an infrared temperature sensor value, which we don't use in this demo.
        // However, for instructional purposes, here's how to get at it to compare to the ambient temperature:
        let rawInfraredTemp:UInt16 = dataArray[Device.SensorDataIndexTempInfrared]
        let infraredTempC = Double(rawInfraredTemp) / 128.0
        let infraredTempF = convertCelciusToFahrenheit(infraredTempC)
        print("*** INFRARED TEMPERATURE SENSOR (C/F): \(infraredTempC), \(infraredTempF)");
        
        if switchStatus == false {
            lastTemperature = Int(ambientTempF)
        }
        print("*** LAST TEMPERATURE CAPTURED: \(lastTemperature)° F")
        
        if UIApplication.shared.applicationState == .active {
            updateTemperatureDisplay()
            if counter % 10 == 0 {
                if counter == 200 {
                    counter = 0
                    tempChange.removeAll()
                    timeStamps.removeAll()
                } else if lastTemperature != Int(ambientTempC) {
                    date = Date()
                    formatter.dateFormat = "hh:mm"
                    currentTime = formatter.string(from: date)
                    tempChange.append(lastTemperature)
                    timeStamps.append(currentTime)
                }
            }
            counter = counter + 1
            print("Counter: \(counter)")
        }
    }
    
    func updateTemperatureDisplay() {
        temperatureLabel.font = UIFont(name: temperatureLabelFontName, size: temperatureLabelFontSizeTemp)
        var text = "\(lastTemperature)"
        text = text.replacingOccurrences(of: "Optional(", with: "")
        text = text.replacingOccurrences(of: ")", with: "")
        temperatureLabel.font = UIFont(name: "Arial Rounded MT Bold", size: 100)
        
        if lastTemperature <= 75 {
            temperatureLabel.textColor = UIColor.blue
        }
        else {
            temperatureLabel.textColor = UIColor.red
        }
        temperatureLabel.text = "\(text)°"
    }
    
    // MARK: Display Humidity
    func displayHumidity(_ data:Data) {
        let dataLength = data.count / MemoryLayout<UInt16>.size
        var dataArray = [UInt16](repeating: 0, count: dataLength)
        (data as NSData).getBytes(&dataArray, length: dataLength * MemoryLayout<Int16>.size)
        
        for i in 0 ..< dataLength {
            let nextInt:UInt16 = dataArray[i]
            print("next int: \(nextInt)")
        }
        
        let rawHumidity:UInt16 = dataArray[Device.SensorDataIndexHumidity]
        let calculatedHumidity = calculateRelativeHumidity(rawHumidity)
        
        humidityLabel.font = UIFont(name: "Arial Rounded MT Bold", size: 45)
        if calculatedHumidity > 0.5 || calculatedHumidity < -0.5 {
            print("*** HUMIDITY: \(calculatedHumidity)");
            humidityLabel.text = String(format: "Humidity: %.01f%%", calculatedHumidity)
        }

        // Humidity sensor also retrieves a temperature, which we don't use.
        // However, for instructional purposes, here's how to get at it to compare to the ambient sensor:
        let rawHumidityTemp:UInt16 = dataArray[Device.SensorDataIndexHumidityTemp]
        let calculatedTemperatureC = calculateHumidityTemperature(rawHumidityTemp)
        let calculatedTemperatureF = convertCelciusToFahrenheit(calculatedTemperatureC)
        print("*** HUMIDITY TEMP C: \(calculatedTemperatureC) F: \(calculatedTemperatureF)")
    }

    // MARK: - TI Sensor Tag Utility Methods
    func convertCelciusToFahrenheit(_ celcius:Double) -> Double {
        let fahrenheit = (celcius * 1.8) + Double(32)
        return fahrenheit
    }
    
    func calculateRelativeHumidity(_ rawH:UInt16) -> Double {
        // clear status bits [1..0]
        let clearedH = rawH & ~0x003
        
        //-- calculate relative humidity [%RH] --
        // RH= -6 + 125 * SRH/2^16
        let relativeHumidity:Double = -6.0 + 125.0/65536 * Double(clearedH)
        return relativeHumidity
    }
    
    func calculateHumidityTemperature(_ rawT:UInt16) -> Double {
        //-- calculate temperature [deg C] --
        let temp = -46.85 + 175.72/65536 * Double(rawT);
        return temp;
    }
    
    //Get Accelerometer values
    /*
    class func getAccelerometerData(value: NSData) -> [Double] {
        let dataFromSensor = dataToSignedBytes16(value)
        
        
        let xVal = Double(dataFromSensor[3]) / 64
        let yVal = Double(dataFromSensor[4]) / 64
        let zVal = Double(dataFromSensor[5]) / 64 * -1
        
        return [xVal, yVal, zVal]
    } */ 
}

