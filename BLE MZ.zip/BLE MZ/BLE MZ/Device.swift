//
//  Device.swift
//  BLE MZ
//
//  Created by C N on 6/20/17.
//  Copyright © 2017 C N. All rights reserved.
//

import Foundation

struct Device {
    
    static let SensorTagAdvertisingUUID = "AA10"
    
    /*
    let MovementServiceUUID = CBUUID(string: "F000AA80-0451-4000-B000-000000000000")
    let MovementDataUUID = CBUUID(string: "F000AA81-0451-4000-B000-000000000000")
    let MovementConfigUUID = CBUUID(string: "F000AA82-0451-4000-B000-000000000000")
    
    let BarometerServiceUUID = CBUUID(string: "F000AA40-0451-4000-B000-000000000000")
    let BarometerDataUUID = CBUUID(string: "F000AA41-0451-4000-B000-000000000000")
    let BarometerConfigUUID = CBUUID(string: "F000AA42-0451-4000-B000-000000000000")
    
    let IOSServiceUUID = CBUUID(string: "F000AA64-0451-4000-B000-000000000000")
    let IOSDataUUID = CBUUID(string: "F000AA65-0451-4000-B000-000000000000")
    let IOSConfigUUID = CBUUID(string: "F000AA66-0451-4000-B000-000000000000")
    */
    
    static let SensorDataIndexTempInfrared = 0
    static let SensorDataIndexTempAmbient = 1
    static let SensorDataIndexHumidityTemp = 0
    static let SensorDataIndexHumidity = 1
}
