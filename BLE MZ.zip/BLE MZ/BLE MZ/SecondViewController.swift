//
//  SecondViewController.swift
//  BLE MZ
//
//  Created by C N on 6/21/17.
//  Copyright © 2017 C N. All rights reserved.
//

import UIKit
import Charts

class SecondViewController: UIViewController {

    // MARK: Properties
    @IBOutlet weak var lineChart: LineChartView!
    @IBOutlet weak var dateLabel: UILabel!
    
    var temp = Int()
    var currentDate = String()
    var drop = false
    var counter = 0
    
    //MARK: Line Chart Properties
    var tempChange : [Int]!
    var currentTime : [String]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Reloads the data
        self.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData() {
        self.lineChart.delegate = self as? ChartViewDelegate
        self.lineChart.chartDescription?.text = ""
        self.lineChart.chartDescription?.textColor = UIColor.white
        self.lineChart.rightAxis.drawLabelsEnabled = false
        self.lineChart.xAxis.drawGridLinesEnabled = false
        self.lineChart.drawGridBackgroundEnabled = true
        self.lineChart.gridBackgroundColor = UIColor(red: 145/255, green: 145/255, blue: 145/255, alpha: 1.00)
        self.lineChart.noDataText = "No data provided"
        setChartData(lineChart, dataPoints: currentTime, values: tempChange)
        
        dateLabel.text = currentDate
        print("Counter: \(counter)")
        counter += 1
    }
    
    // MARK: Line Chart functions
    func setChartData(_ lineChartView: LineChartView, dataPoints: [String], values: [Int]) {
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<tempChange.count {
            let dataEntry = ChartDataEntry(x: Double(i), y: Double(values[i]))
            dataEntries.append(dataEntry)
        }
        
        let lineChartDataSet = LineChartDataSet(values: dataEntries, label: "Temperature")
        lineChartDataSet.setColor(UIColor(red: 128/255, green: 220/255, blue: 235/255, alpha: 1.00))
        // lineChartDataSet.drawCubicEnabled = true
        lineChartDataSet.mode = .cubicBezier
        lineChartDataSet.drawCirclesEnabled = false
        lineChartDataSet.lineWidth = 1.75
        lineChartDataSet.circleRadius = 5.0
        lineChartDataSet.highlightColor = UIColor.red
        lineChartDataSet.drawHorizontalHighlightIndicatorEnabled = true
        lineChartDataSet.valueFont = UIFont(name: "Arial Rounded MT Bold", size: 11)!
        
        // Display the number values as integers
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .none
        numberFormatter.locale = Locale.current
        let valuesNumberFormatter = ChartValueFormatter(numberFormatter: numberFormatter)
        lineChartDataSet.valueFormatter = valuesNumberFormatter
        lineChartDataSet.valueFont = lineChartDataSet.valueFont.withSize(11)
        
        var dataSets = [IChartDataSet]()
        dataSets.append(lineChartDataSet)
        
        let lineChartData = LineChartData(dataSets: dataSets)
        
        // Appearance
        lineChartView.data = lineChartData
        lineChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: currentTime)
        lineChartView.xAxis.granularity = 1
        lineChartView.xAxis.labelRotationAngle = CGFloat(-50.0) //solve last label being cut off
        lineChartView.xAxis.labelFont = UIFont(name: "Arial Rounded MT Bold", size: 12)!
        lineChartView.xAxis.labelPosition = XAxis.LabelPosition.bottom
        lineChartView.leftAxis.labelFont = UIFont(name: "Arial Rounded MT Bold", size: 11)!
        lineChartView.leftAxis.granularityEnabled = true
        lineChartView.leftAxis.granularity = 1.0
        
        let legend = lineChart.legend
        legend.font = UIFont(name: "Arial Rounded MT Bold", size: 14)!
    }
    
    // MARK: Convert chart values to integer formatter
    class ChartValueFormatter : NSObject, IValueFormatter {
        fileprivate var numberFormatter: NumberFormatter?
        
        convenience init(numberFormatter: NumberFormatter) {
            self.init()
            self.numberFormatter = numberFormatter
        }
        
        func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
            guard let numberFormatter = numberFormatter
                else {
                    return ""
            }
            return numberFormatter.string(for: value)!
        }
    }
    
}
