//
//  ViewController.swift
//  AVT MiniZed
//
//  Created by C N on 7/17/17.
//  Copyright © 2017 C N. All rights reserved.
//

import UIKit
import SceneKit
import CoreBluetooth
import CoreMotion

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate, SCNSceneRendererDelegate, SCNPhysicsContactDelegate {

    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var sceneView: SCNView!
    @IBOutlet weak var coordinateText: UITextView!
    @IBOutlet weak var xLabel: UILabel!
    @IBOutlet weak var yLabel: UILabel!
    @IBOutlet weak var zLabel: UILabel!
    
    var motionManager = CMMotionManager()
    
    // Scene materials
    let scene = SCNScene() // Create the scene
    var accX: Double = 0.0, accY: Double = 0.0, accZ: Double = 0.0
    
    let boxGeom = SCNBox(width: 2, height: 2, length: 20, chamferRadius: 0.2)
    let boxGeom1 = SCNBox(width: 2, height: 2, length: 20, chamferRadius: 0.2)
    let boxGeom2 = SCNBox(width: 20, height: 2, length: 2, chamferRadius: 0.2)
    let boxGeom3 = SCNBox(width: 20, height: 2, length: 2, chamferRadius: 0.2)
    
    var cubeNode: SCNNode = SCNNode(), sphereNode: SCNNode = SCNNode()
    var boxNode: SCNNode = SCNNode(), boxNode1: SCNNode = SCNNode(), boxNode2: SCNNode = SCNNode(), boxNode3: SCNNode = SCNNode()
    var avtGreen = UIColor.init(red: 65/255, green: 195/255, blue: 99/255, alpha: 1.0)
    var avtBlue = UIColor.init(red: 128/255, green: 220/255, blue: 235/255, alpha: 1.0)
    var avtYellow = UIColor.init(red: 255/255, green: 209/255, blue: 0/255, alpha: 1.0)
    var avtWhite = UIColor.white
    var coordinateArray:Array = [String]()
    
    let ball: Int = 1 // 1<< 1     ; //0x0000000001
    let greenBox: Int = 2 // 1 << 2  ; //0x0000000010
    
    // BLE Properties
    var centralManager : CBCentralManager!
    var sensorTagPeripheral : CBPeripheral!
    var accelerometerCharacteristic:CBCharacteristic?
    var temperatureCharacteristic:CBCharacteristic?
    var counter = 0
    
    // IR Temp, Humidity UUIDs
    let IRTemperatureServiceUUID = CBUUID(string: "F000AA00-0451-4000-B000-000000000000")
    let IRTemperatureDataUUID = CBUUID(string: "F000AA01-0451-4000-B000-000000000000")
    let IRTemperatureConfig = CBUUID(string: "F000AA02-0451-4000-B000-000000000000")
    
    // MARK: BLE Section
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Initialize central manager on load
        centralManager = CBCentralManager(delegate: self, queue: nil, options: nil)
        motionManager.startAccelerometerUpdates()
        
        setupScene()
        sceneView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        motionManager.accelerometerUpdateInterval = 0.3
        
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            if let myData = data {
                self.xLabel.text = String(format: "X: %.3f", myData.acceleration.x)
                self.yLabel.text = String(format: "Y: %.3f", myData.acceleration.y)
                self.zLabel.text = String(format: "Z: %.3f", myData.acceleration.z)
                
                // Simulation Data for Temperature
                if myData.acceleration.y > 0 {
                    self.temperatureLabel.text = "75°"
                } else {
                    self.temperatureLabel.text = "74°"
                }
            }
        }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if let accelerometerData = motionManager.accelerometerData {
            scene.physicsWorld.gravity = SCNVector3(accelerometerData.acceleration.y * 20, -10, (accelerometerData.acceleration.x - 0.5) * 5)
        }
    }
    
    func setupScene() {
        sceneView.scene = scene
        sceneView.scene?.physicsWorld.contactDelegate = self
        setUpEnvironment()
        
        // Create a camera and attach it to a node
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 10, z: 25)
        
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = SCNLight.LightType.directional
        lightNode.position = SCNVector3(x: 0, y: 10, z: 5)
        
        let ambiLightNode = SCNNode()
        ambiLightNode.light = SCNLight()
        ambiLightNode.light?.type = SCNLight.LightType.ambient
        ambiLightNode.light?.color = UIColor.gray
        
        let center = SCNNode()
        lightNode.constraints = [SCNLookAtConstraint(target: center)]
        cameraNode.constraints = [SCNLookAtConstraint(target: center)]
        
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(lightNode)
        scene.rootNode.addChildNode(ambiLightNode)
    }
    
    func sphereInfo() {
        self.sphereNode.isPaused = false
        
        // Update the Coordinate Text Box
        let coordinates = "\n\(String(format: "X: %.3f ", sphereNode.position.x)) \(String(format: "Y: %.3f ", sphereNode.position.y)) \(String(format: "Z: %.3f", sphereNode.position.z))"
        coordinateArray.append(coordinates)
        coordinateText.isEditable = false
        coordinateText.text! += coordinateArray.last!
        coordinateText.scrollRangeToVisible(NSMakeRange(coordinateText.text.characters.count - 1, 0))
    }
    
    func setUpEnvironment() {
        // Creates the Sphere
        let sphere = SCNSphere(radius: 2.25)
        sphere.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "shutterstock_425758117")
        sphere.firstMaterial?.isDoubleSided = true
        let sphereNode = SCNNode(geometry: sphere)
        sphereNode.position = SCNVector3(x: 0.0, y: 0.0, z: 0.0)
        sphereNode.name = "ball"
        self.sphereNode = sphereNode
        sphereNode.physicsBody = SCNPhysicsBody.dynamic()
        sphereNode.physicsBody?.restitution = 0.8
        sphereNode.physicsBody?.mass = 0.47
        sphereNode.physicsBody?.categoryBitMask = ball
        sphereNode.physicsBody?.collisionBitMask = greenBox
        sphereNode.physicsBody?.contactTestBitMask = greenBox
        scene.rootNode.addChildNode(sphereNode)
        
        // Creates the floor
        let floorGeo = SCNFloor()
        floorGeo.firstMaterial?.diffuse.contents = UIColor.black
        let floorNode = SCNNode(geometry: floorGeo)
        floorNode.physicsBody = SCNPhysicsBody(type: SCNPhysicsBodyType.static, shape: SCNPhysicsShape(geometry: floorGeo, options: nil))
        floorNode.physicsBody?.friction = 0.7
        scene.rootNode.addChildNode(floorNode)
        
        // Creates the rectangular boxes
        boxGeom.firstMaterial?.diffuse.contents = avtGreen
        let boxNode = SCNNode(geometry: boxGeom)
        boxNode.position = SCNVector3(x: -15, y: 1, z: 0)
        boxNode.name = "greenBox"
        boxNode.physicsBody = SCNPhysicsBody.static()
        boxNode.physicsBody?.categoryBitMask = greenBox
        boxNode.physicsBody?.contactTestBitMask = ball
        boxNode.physicsBody?.collisionBitMask = ball
        scene.rootNode.addChildNode(boxNode)
        
        boxGeom1.firstMaterial?.diffuse.contents = avtBlue
        let boxNode1 = SCNNode(geometry: boxGeom1)
        boxNode1.name = "blueBox"
        scene.rootNode.addChildNode(boxNode1)
        boxNode1.position = SCNVector3(x: 15, y: 1, z: 0)
        boxNode1.physicsBody = SCNPhysicsBody.static()
        
        boxGeom2.firstMaterial?.diffuse.contents = avtYellow
        let boxNode2 = SCNNode(geometry: boxGeom2)
        boxNode2.name = "yellowBox"
        scene.rootNode.addChildNode(boxNode2)
        boxNode2.position = SCNVector3(x: -11, y: 1, z: -10)
        boxNode2.physicsBody = SCNPhysicsBody.static()

        boxGeom3.firstMaterial?.diffuse.contents = avtWhite
        let boxNode3 = SCNNode(geometry: boxGeom3)
        boxNode3.name = "whiteBox"
        scene.rootNode.addChildNode(boxNode3)
        boxNode3.position = SCNVector3(x: 11, y: 1, z: -10)
        boxNode3.physicsBody = SCNPhysicsBody.static()
    }
    
    // MARK: Contact
    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
        let avtColors = [avtGreen, avtBlue, avtYellow, avtWhite, avtBlue, avtGreen, avtWhite, avtYellow]
        let n = Int(arc4random_uniform(8))
        
        // Determines which box the ball hit, and then changes the box's color
        if (contact.nodeA.name == "ball" && contact.nodeB.name == "greenBox" ) || (contact.nodeB.name == "ball" && contact.nodeA.name == "greenBox" ) {
            boxGeom.firstMaterial?.diffuse.contents = avtColors[n]
        } else if (contact.nodeA.name == "ball" && contact.nodeB.name == "blueBox") || (contact.nodeB.name == "ball" && contact.nodeA.name == "blueBox") {
            boxGeom1.firstMaterial?.diffuse.contents = avtColors[n]
        } else if (contact.nodeA.name == "ball" && contact.nodeB.name == "yellowBox") || (contact.nodeB.name == "ball" && contact.nodeA.name == "yellowBox") {
            boxGeom2.firstMaterial?.diffuse.contents = avtColors[n]
        } else if (contact.nodeA.name == "ball" && contact.nodeB.name == "whiteBox") || (contact.nodeB.name == "ball" && contact.nodeA.name == "whiteBox") {
            boxGeom3.firstMaterial?.diffuse.contents = avtColors[n]
        }
    }
    
    // MARK: Swipe Gestures
    @IBAction func swipeRight(_ sender: UISwipeGestureRecognizer) {
        sphereInfo()
        let moveBy = SCNAction.moveBy(x: 5, y: 0, z: 0, duration: 0.2)
        sphereNode.runAction(moveBy)
    }
    
    @IBAction func swipeLeft(_ sender: UISwipeGestureRecognizer) {
        sphereInfo()
        let moveBy = SCNAction.moveBy(x: -5, y: 0, z: 0, duration: 0.2)
        sphereNode.runAction(moveBy)
    }
    
    @IBAction func swipeUp(_ sender: UISwipeGestureRecognizer) {
        sphereInfo()
        let moveBy = SCNAction.moveBy(x: 0, y: 5, z: 0, duration: 0.2)
        sphereNode.runAction(moveBy)
    }
    
    @IBAction func swipeDown(_ sender: UISwipeGestureRecognizer) {
       sphereInfo()
        let moveBy = SCNAction.moveBy(x: 0, y: -5, z: 0, duration: 0.2)
        sphereNode.runAction(moveBy)
    }
    
    @IBAction func resetBall(_ sender: Any) {
        sphereNode.position = SCNVector3(0,0,0)
    }
    
    @IBAction func resetBox(_ sender: UITapGestureRecognizer) {
        self.sphereNode.isPaused = true
        sphereNode.position = SCNVector3(0,0,0)
    }

    
    // MARK: BLE Status
    //Check status of BLE hardware
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            // Scan for peripherals if BLE is turned on
            central.scanForPeripherals(withServices: nil, options: nil)
            //self.statusLabel.text = "Searching for BLE Devices"
            self.statusLabel.text = "Connected"
        }
        else {
            // Can have different conditions for all states if needed - print generic message
            self.statusLabel.text = "Bluetooth Off"
            print("Bluetooth switched off or not initialized")
        }
    }
    
    // Check out the discovered peripherals to find Sensor Tag
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let deviceName = "CC2650 SensorTag"
        let nameOfDeviceFound = (advertisementData as NSDictionary).object(forKey: CBAdvertisementDataLocalNameKey) as? String
        
        if nameOfDeviceFound == deviceName {
            // Update Status Label
            
            // Stop scanning
            self.centralManager.stopScan()
            // Set as the peripheral to use and establish connection
            self.sensorTagPeripheral = peripheral
            self.sensorTagPeripheral.delegate = self
            self.centralManager.connect(peripheral, options: nil)
        } else {
            print("BLE Device NOT Found")
        }
    }
    
    // Discover services of the peripheral
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        self.statusLabel.text = "Discovering peripheral services"
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }
    
    // Check if the service is discovered a valid IR Temperature Service
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        self.statusLabel.text = "Looking at peripheral services"
        if let services = peripheral.services {
            for service in services {
                let thisService = service as CBService
                /*
                if service.uuid ==  {
                    peripheral.discoverCharacteristics(nil, for: thisService)
                } */
                print(service.uuid)
            }
        }
    }
    
    // Enable notification and sensor for each characteristic of valid service
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        // update status label
        self.statusLabel.text = "Enabling Sensors"
        
        guard let characteristics = service.characteristics
            else { print("Unable to retrieve service characteristics"); return }
        
        var enableValue: UInt8 = 1
        let enableBytes = NSData(bytes: &enableValue, length: MemoryLayout<UInt8>.size)
        
        for characteristic in characteristics {
            
            switch(characteristic.uuid) {
                /*
            case IRTemperatureDataUUID:
                self.sensorTagPeripheral.setNotifyValue(true, for: characteristic)
                temperatureCharacteristic = characteristic
            case IRTemperatureConfig:
                self.sensorTagPeripheral.writeValue(enableBytes as Data, for: characteristic, type: .withResponse) */
                default:
                break
            }
        }
    }
    
    // Get data values when they are updated
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        self.statusLabel.text = "Connected"
        
        switch(characteristic.uuid) {
            /*
        case IRTemperatureDataUUID:
            displayTemperature(characteristic.value!)
            fallthrough*/
        default:
            break
        }
    }
    
    // If disconnected, start searching again
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        self.statusLabel.text = "Disconnected"
        central.scanForPeripherals(withServices: nil, options: nil)
    }
    
}
