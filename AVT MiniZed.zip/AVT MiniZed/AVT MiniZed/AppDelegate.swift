//
//  AppDelegate.swift
//  AVT MiniZed
//
//  Created by C N on 7/17/17.
//  Copyright © 2017 C N. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

}


/*
 
 // Create a cube and place it in the scene
 /*
 let cube = SCNBox(width: 15, height: 15, length: 15, chamferRadius: 0.0)
 let greenMaterial = SCNMaterial(), blueMaterial = SCNMaterial(), lightGrayMaterial = SCNMaterial(), grayMaterial = SCNMaterial()
 greenMaterial.diffuse.contents = UIColor(red: 65/255, green: 195/255, blue: 99/255, alpha: 1.0)
 blueMaterial.diffuse.contents = UIColor(red: 128/255, green: 220/255, blue: 235/255, alpha: 1.0)
 lightGrayMaterial.diffuse.contents = UIColor(red: 210/255, green: 210/255, blue: 210/255, alpha: 1.0)
 grayMaterial.diffuse.contents = UIColor(red: 145/255, green: 145/255, blue: 145/255, alpha: 1.0)
 cube.materials = [greenMaterial, blueMaterial, greenMaterial, blueMaterial, lightGrayMaterial, grayMaterial]
 
 let cubeNode = SCNNode(geometry: cube)
 scene.rootNode.addChildNode(cubeNode)
 self.cubeNode = cubeNode */
 
 let coordinates = "\nX: \(cubeNode!.position.x) Y: \(cubeNode!.position.y) Z: \(cubeNode!.position.z)"
 coordinateArray.append(coordinates)
 
 coordinateText.isEditable = false
 coordinateText.text! += coordinateArray.last!
 
 let moveBy = SCNAction.moveBy(x: 10, y: 0, z: 0, duration: 1.5)
 cubeNode?.runAction(moveBy)
 
 self.view.addSubview(cubeView)
 
 let scene = SCNScene()
 cubeView.scene = scene
 
 let camera = SCNCamera()
 let cameraNode = SCNNode()
 cameraNode.camera = camera
 cameraNode.position = SCNVector3(x: -3.0, y: 3.0, z: 3.0)
 
 let light = SCNLight()
 light.type = SCNLight.LightType.omni
 let lightNode = SCNNode()
 lightNode.light = light
 lightNode.position = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
 
 let cubeGeometry = SCNBox(width: 2.0, height: 2.0, length: 2.0, chamferRadius: 0.0)
 let cubeNode1 = SCNNode(geometry: cubeGeometry)
 
 /*
 let planeGeometry = SCNPlane(width: 50.0, height: 50.0)
 let planeNode = SCNNode(geometry: planeGeometry)
 planeNode.eulerAngles = SCNVector3(x: GLKMathDegreesToRadians(-90), y: 0.0, z: 0.0)
 planeNode.position = SCNVector3(x: 0, y: -0.5, z: 0)
 */
 let redMaterial = SCNMaterial()
 redMaterial.diffuse.contents = UIColor.red
 cubeGeometry.materials = [redMaterial]
 
 let greenMaterial = SCNMaterial()
 greenMaterial.diffuse.contents = UIColor.green
 //planeGeometry.materials = [greenMaterial]
 
 let constraint = SCNLookAtConstraint(target: cubeNode1)
 constraint.isGimbalLockEnabled = true
 cameraNode.constraints = [constraint]
 
 scene.rootNode.addChildNode(lightNode)
 scene.rootNode.addChildNode(cameraNode)
 scene.rootNode.addChildNode(cubeNode1)
 //scene.rootNode.addChildNode(planeNode)
 
 func cubeInfo() {
 self.cubeNode.isPaused = false
 
 let coordinates = "\nX: \(cubeNode.position.x) Y: \(cubeNode.position.y) Z: \(cubeNode.position.z)"
 coordinateArray.append(coordinates)
 coordinateText.isEditable = false
 coordinateText.text! += coordinateArray.last!
 coordinateText.scrollRangeToVisible(NSMakeRange(coordinateText.text.characters.count - 1, 0))
 }
 
 /*
 override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
 
 let touch = touches.first
 if let touchPoint = touch?.location(in: sceneView),
 let hitTestResult = sceneView.hitTest(touchPoint, options: nil).first {
 let hitNode = hitTestResult.node
 //hitNode.isPaused = !hitNode.isPaused
 }
 
 let coordinates = "\nX: \(cubeNode.position.x) Y: \(cubeNode.position.y) Z: \(cubeNode.position.z)"
 coordinateArray.append(coordinates)
 coordinateText.isEditable = false
 coordinateText.text! += coordinateArray.last!
 } */
 
 
 // Add an animation to the sphere.
 /*
 let animation = CAKeyframeAnimation(keyPath: "rotation")
 animation.values = [SCNVector4(1, 1, 0.3, 0 * .pi),
 SCNVector4(1, 0.4, 0.3, 1 * .pi),
 SCNVector4(1, 1, 0.2, 2 * .pi)] //(x, y, z, degreetoRadian
 animation.duration = 5
 animation.repeatCount = HUGE
 self.sphereNode.addAnimation(animation, forKey: "rotation")
 self.sphereNode.isPaused = true // Start out paused */
 
 */
